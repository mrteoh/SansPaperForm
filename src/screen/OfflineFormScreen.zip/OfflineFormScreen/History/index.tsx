//library
import { setLogVerbosity, useQuery } from '@apollo/client';
import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Platform,
  RefreshControl,
} from 'react-native';
import { ButtonGroup } from 'react-native-elements';
import { useDispatch, useSelector } from 'react-redux';
import { GET_HISTORY_FORMS } from 'graphql/queries/form';
import { Colors } from '../../../styles/colors';
import { FAMILY, SIZE } from '../../../styles/font';
import { KeyboardAwareFlatList } from 'react-native-keyboard-aware-scroll-view';
import { Spaces } from '../../../styles/space';
import { selectUserData } from 'selector/user';
import { pushScreenOnHistoryScreen } from 'navigation/componentNavigation';
import { Screens } from 'constant/ScreenConstants';

const buttons = ['Sent', 'Open'];

const HistoryScreen = () => {
  const dispatch = useDispatch();
  const [selected, setSelected] = useState(0);
  const [historyForms, setHistoryForms] = useState([]);
  const userData = useSelector(selectUserData);
  // console.log('---- userData', userData)

  //get user Id
  let getUserId;

  if (userData) {
    getUserId = userData.id;
  }

  const { loading, error, data, refetch } = useQuery(GET_HISTORY_FORMS, {
    variables: {
      userId: getUserId,
    },
  });

  const onPressItem = async (formData: any) => {

    pushScreenOnHistoryScreen({
      componentId: Screens.FILLEDUP_FORM_FIELDS_SCREEN,
      passProps: { formData },
    });
  };


  useEffect(() => {
    console.log('---- data', data)
    setHistoryForms(data?.fillupForms?.data);
  }, [data]);

  const renderHistory = ({ item, index }: any) => {
    return (
      <TouchableOpacity
        onPress={() => onPressItem(item)}
        style={styles.itemContainer}>
        <Text style={styles.itemLabel}>{item.form.name} (ID: {item.id})</Text>
        <Text style={styles.itemDescription}>{item.form.description}</Text>
      </TouchableOpacity>
    );
  };

  return (
    <View style={styles.container}>
      <View style={styles.headerContainer}>
        <Text style={styles.headerText}>FORM HISTORY</Text>
        <Text style={styles.subText}>Recent</Text>
      </View>
      <ButtonGroup
        onPress={setSelected}
        selectedIndex={selected}
        buttons={buttons}
        textStyle={styles.btnText}
        containerStyle={styles.btnContainer}
        selectedButtonStyle={{ backgroundColor: Colors.AltRed }}
      />
      <View style={{ paddingTop: 15, flex: 1 }}>
        <KeyboardAwareFlatList
          keyExtractor={item => item.id}
          data={historyForms}
          initialNumToRender={500}
          showsVerticalScrollIndicator={false}
          renderItem={renderHistory}
          removeClippedSubviews={false}
          extraScrollHeight={Platform.OS === 'ios' ? 50 : 0}
          enableOnAndroid={true}
          enableResetScrollToCoords={false}
          refreshControl={
            <RefreshControl
              refreshing={loading}
              onRefresh={refetch}
            />
          }

        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 15,
    backgroundColor: Colors.DirtyWhite
  },
  btnContainer: {
    borderRadius: 5,
    borderColor: Colors.AltRed,
  },
  btnText: {
    fontFamily: FAMILY.QUICKSAND_REGULAR,
    color: Colors.AltRed,
  },
  headerContainer: {
    marginHorizontal: 10,
  },
  headerText: {
    fontFamily: FAMILY.QUICKSAND_REGULAR,
    fontSize: SIZE.SMALL,
    color: Colors.DarkGray,
  },
  subText: {
    fontFamily: FAMILY.QUICKSAND_BOLD,
    fontSize: SIZE.LARGE,
    color: Colors.Gray,
  },
  titleView: {
    flex: 1,
    marginRight: 20,
  },
  title: {
    fontFamily: FAMILY.QUICKSAND_REGULAR,
    fontSize: SIZE.REGULAR,
    letterSpacing: 0.2,
    color: Colors.DarkGray,
  },
  cardView: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  itemContainer: {
    backgroundColor: Colors.White,
    marginBottom: Spaces.SuperSuperSmall,
    paddingHorizontal: Spaces.Small,
    paddingVertical: Spaces.Small,
  },
  itemLabel: {
    color: Colors.DarkGray,
    fontFamily: FAMILY.QUICKSAND_SEMI_BOLD,
    fontSize: SIZE.REGULAR,
    flex: 1,
  },
  itemDescription: {
    color: Colors.DarkGray,
    fontFamily: FAMILY.QUICKSAND_REGULAR,
    fontSize: SIZE.SMALL,
    flex: 1,
  },
});

export default HistoryScreen;
