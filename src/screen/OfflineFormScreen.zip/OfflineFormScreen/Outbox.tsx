import React from 'react';
import { View, Text, TouchableOpacity, TouchableHighlight, Platform } from 'react-native';
import { styles } from './styles';
import { Icon, Card, SearchBar, Button } from 'react-native-elements';

import { showAuthenticationScreen } from 'navigation';
import { Colors } from 'react-native-paper';

const Outbox = () => {
  return (
    <>
      <View style={styles.header}>
        <SearchBar
          placeholder="Search outbox"
          containerStyle={styles.searchContainer}
          inputContainerStyle={styles.searchInputContainer}
          inputStyle={styles.searchInput}
        // onChangeText={this.updateSearch}
        // value={search}
        />

        <View style={styles.filterView}>
          <View
            style={{
              flexDirection: 'row',
              paddingLeft: 20,
              alignItems: 'center',
            }}>
            <TouchableHighlight
              underlayColor="transparent"
            // onPress={this.onFilterOutboxList}
            >
              <View style={styles.filter}>
                {Platform.OS === 'android' ? (
                  <Icon type="antdesign" name="filter" color={Colors.white} />
                ) : (
                  <Icon type="ionicon" name="options-outline" color={Colors.white} />
                )}
                <Text style={styles.filterText}>filter label</Text>
              </View>
            </TouchableHighlight>
            <TouchableHighlight
              underlayColor="transparent"
            // onPress={this.onOrderFormBy}
            >
              <View style={styles.filter}>
                <Icon
                  type="font-awesome"
                  name="sort"
                  color={Colors.white}
                  size={20}
                />
                <Text style={styles.filterText}>orderBy</Text>
              </View>
            </TouchableHighlight>
            <TouchableHighlight
              underlayColor="transparent"
            // onPress={this.onSortBy}
            >
              <View style={styles.filter}>
                <Icon
                  type="font-awesome"
                  name={`sort-alpha-asc`}
                  size={18}
                  color={Colors.white}
                />
                <Text style={styles.filterText}>sortBy</Text>
              </View>
            </TouchableHighlight>
          </View>
        </View>

      </View>
    </>
  );
};

export default Outbox;
